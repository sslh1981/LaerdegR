oppg2.2<-function(){
  hoyre<-c(3.75, 7.5, 7.25, 6, 2.25, 4, 1.5, 6.75)
  median(hoyre) #medianen for hoyreorientering
  median(hoyre)==hoyre #ingen observasjoner har medianverdien
  }
