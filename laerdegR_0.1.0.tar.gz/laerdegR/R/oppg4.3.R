oppg4.3<-function(){
  requireNamespace("datasets")
  data("cars")
  ?cars
}
